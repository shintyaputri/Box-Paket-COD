export { default as LoginIllustration } from './LoginIllustration';
export { default as RegisterIllustration } from './RegisterIllustration';
export { default as ForgotPasswordIllustration } from './ForgotPasswordIllustration';